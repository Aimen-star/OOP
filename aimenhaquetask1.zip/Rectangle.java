/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aimenhaquetask1;

/**
 *
 * @author Az
 */
import java.util.Scanner;
public class Rectangle extends Shape {
    double length;
    double width;
    double calculateArea(){
        return length*width;
    }
    void getInput(){
        Scanner scan=new Scanner(System.in);
        System.out.println(" Length: " );
          length =scan.nextDouble();   
          System.out.println(" Width: ");
          width =scan.nextDouble();   
          scan.close();
    }
    void displayRectangle(){
        System.out.println(" Area of rectangle is "+ calculateArea() );
        
    }
}


