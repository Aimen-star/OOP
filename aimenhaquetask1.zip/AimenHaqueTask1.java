/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aimenhaquetask1;

/**
 *
 * @author Az
 */

public class AimenHaqueTask1 {
    public static void main(String[] args) {
       Rectangle r=new Rectangle();
       r.display();
       r.getInput();
       r.displayRectangle();
          
    }
}
