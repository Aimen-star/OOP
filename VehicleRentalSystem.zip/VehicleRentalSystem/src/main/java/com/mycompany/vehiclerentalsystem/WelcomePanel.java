/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.vehiclerentalsystem;

/**
 *
 * @author Az
 */
/*import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class WelcomePanel extends JPanel {

    public WelcomePanel(CardLayout cardLayout, JPanel mainPanel) {
        setBackground(new Color(0, 102, 204));
        setLayout(new BorderLayout());

        // Title Label
        JLabel label = new JLabel("Welcome to Vehicle Rental System", SwingConstants.CENTER);
        label.setFont(new Font("Verdana", Font.BOLD, 26));
        label.setForeground(Color.WHITE);
        add(label, BorderLayout.CENTER);

        // Continue Button
        JButton continueButton = new JButton("Continue");
        continueButton.setFont(new Font("Verdana", Font.PLAIN, 18));
        continueButton.setBackground(Color.WHITE);
        continueButton.setForeground(new Color(0, 102, 204));
        continueButton.setFocusPainted(false);  // Removes focus border

        // Hover Effect for the Continue Button
        continueButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                continueButton.setBackground(new Color(0, 102, 204));
                continueButton.setForeground(Color.WHITE);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                continueButton.setBackground(Color.WHITE);
                continueButton.setForeground(new Color(0, 102, 204));
            }
        });

        // Action: switch to next card when clicked
        continueButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(mainPanel, "AddVehicle"); // Change to your actual next panel name
            }
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(0, 102, 204));
        buttonPanel.add(continueButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }
}*/
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class WelcomePanel extends JPanel {

    public WelcomePanel(CardLayout cardLayout, JPanel mainPanel) {
        setBackground(new Color(0, 102, 204));
        setLayout(new BorderLayout());

        JLabel label = new JLabel("Welcome to Vehicle Rental System", SwingConstants.CENTER);
        label.setFont(new Font("Verdana", Font.BOLD, 26));
        label.setForeground(Color.WHITE);
        add(label, BorderLayout.CENTER);

        JButton continueButton = new JButton("Continue");
        continueButton.setFont(new Font("Verdana", Font.PLAIN, 18));
        continueButton.setBackground(Color.WHITE);
        continueButton.setForeground(new Color(0, 102, 204));
        continueButton.setFocusPainted(false);

        continueButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                continueButton.setBackground(new Color(0, 102, 204));
                continueButton.setForeground(Color.WHITE);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                continueButton.setBackground(Color.WHITE);
                continueButton.setForeground(new Color(0, 102, 204));
            }
        });

        continueButton.addActionListener(e -> cardLayout.show(mainPanel, "AddVehicle"));

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(0, 102, 204));
        buttonPanel.add(continueButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }
}


