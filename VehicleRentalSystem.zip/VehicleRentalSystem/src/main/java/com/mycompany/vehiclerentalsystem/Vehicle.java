/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.vehiclerentalsystem;

/**
 *
 * @author Az
 */
import java.io.Serializable;
import java.time.LocalDate;

public class Vehicle implements Serializable {
    private String model;
    private String plate;
    private boolean rented;
    private String rentedByCustomer;
    private LocalDate rentalDate;

    public Vehicle(String model, String plate) {
        this.model = model;
        this.plate = plate;
        this.rented = false;
    }

    Vehicle(String id, String type, String brand, String modelText, String availability) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getPlate() {
        return plate;
    }

    public boolean isRented() {
        return rented;
    }

    public String getRentedByCustomer() {
        return rentedByCustomer;
    }

    public LocalDate getRentalDate() {
        return rentalDate;
    }

    public void rent(String customer) {
        this.rented = true;
        this.rentedByCustomer = customer;
        this.rentalDate = LocalDate.now();
    }

    public void returnVehicle() {
        this.rented = false;
        this.rentedByCustomer = null;
        this.rentalDate = null;
    }

    public String toString() {
        return "Model: " + model + ", Plate: " + plate + ", Status: " + (rented ? "Rented to " + rentedByCustomer + " on " + rentalDate : "Available");
    }

    public Object[] toRow() {
        return new Object[]{
            plate, 
            model, 
            rented ? "Rented" : "Available", 
            rentedByCustomer != null ? rentedByCustomer : "N/A", 
            rentalDate != null ? rentalDate.toString() : "N/A"
        };
    }

    String getId() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

