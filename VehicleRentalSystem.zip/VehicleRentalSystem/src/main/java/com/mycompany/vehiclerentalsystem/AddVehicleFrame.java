/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.vehiclerentalsystem;

/**
 *
 * @author Az
 */
/*import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class AddVehicleFrame extends JFrame {
    private JTextField txtVehicleID, txtVehicleType, txtBrand, txtModel;
    private JComboBox<String> comboAvailability;
    private JTable table;
    private DefaultTableModel model;

    public AddVehicleFrame() {
        setTitle("Add Vehicle");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        model = new DefaultTableModel(new String[]{"ID", "Type", "Brand", "Model", "Availability"}, 0);
        table = new JTable(model);

        add(createInputPanel(), BorderLayout.NORTH);
        add(createButtonPanel(), BorderLayout.CENTER);
        add(createTablePanel(), BorderLayout.SOUTH);
    }

    private JPanel createInputPanel() {
        JPanel inputPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        inputPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("Vehicle Details"),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));

        txtVehicleID = new JTextField();
        txtVehicleType = new JTextField();
        txtBrand = new JTextField();
        txtModel = new JTextField();
        comboAvailability = new JComboBox<>(new String[]{"Available", "Not Available"});

        inputPanel.add(new JLabel("Vehicle ID:")); inputPanel.add(txtVehicleID);
        inputPanel.add(new JLabel("Type:")); inputPanel.add(txtVehicleType);
        inputPanel.add(new JLabel("Brand:")); inputPanel.add(txtBrand);
        inputPanel.add(new JLabel("Model:")); inputPanel.add(txtModel);
        inputPanel.add(new JLabel("Availability:")); inputPanel.add(comboAvailability);

        return inputPanel;
    }

    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel(new FlowLayout());

        JButton btnAdd = new JButton("Add");
        JButton btnUpdate = new JButton("Update");
        JButton btnDelete = new JButton("Delete");

        buttonPanel.add(btnAdd);
        buttonPanel.add(btnUpdate);
        buttonPanel.add(btnDelete);

        btnAdd.addActionListener(e -> addVehicle());
        btnUpdate.addActionListener(e -> updateVehicle());
        btnDelete.addActionListener(e -> deleteVehicle());

        return buttonPanel;
    }

    private JScrollPane createTablePanel() {
        JScrollPane scrollPane = new JScrollPane(table);

        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                txtVehicleID.setText(model.getValueAt(row, 0).toString());
                txtVehicleType.setText(model.getValueAt(row, 1).toString());
                txtBrand.setText(model.getValueAt(row, 2).toString());
                txtModel.setText(model.getValueAt(row, 3).toString());
                comboAvailability.setSelectedItem(model.getValueAt(row, 4).toString());
            }
        });

        return scrollPane;
    }

    private void addVehicle() {
        Vehicle v = getVehicleFromForm();
        if (v == null) return;

        if (isDuplicateID(v.id, -1)) {
            JOptionPane.showMessageDialog(this, "Vehicle ID already exists.");
            return;
        }

        model.addRow(v.toRow());
        clearForm();
    }

    private void updateVehicle() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Select a row to update.");
            return;
        }

        Vehicle v = getVehicleFromForm();
        if (v == null) return;

        if (isDuplicateID(v.id, row)) {
            JOptionPane.showMessageDialog(this, "Vehicle ID already exists.");
            return;
        }

        for (int i = 0; i < 5; i++) {
            model.setValueAt(v.toRow()[i], row, i);
        }

        clearForm();
    }

    private void deleteVehicle() {
        int row = table.getSelectedRow();
        if (row != -1) {
            model.removeRow(row);
            clearForm();
        } else {
            JOptionPane.showMessageDialog(this, "Select a row to delete.");
        }
    }

    private Vehicle getVehicleFromForm() {
        String id = txtVehicleID.getText().trim();
        String type = txtVehicleType.getText().trim();
        String brand = txtBrand.getText().trim();
        String modelText = txtModel.getText().trim();
        String availability = (String) comboAvailability.getSelectedItem();

        if (id.isEmpty() || type.isEmpty() || brand.isEmpty() || modelText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.");
            return null;
        }

        return new Vehicle(id, type, brand, modelText, availability);
    }

    private boolean isDuplicateID(String id, int excludeRow) {
        for (int i = 0; i < model.getRowCount(); i++) {
            if (i != excludeRow && model.getValueAt(i, 0).toString().equals(id)) {
                return true;
            }
        }
        return false;
    }

    private void clearForm() {
        txtVehicleID.setText("");
        txtVehicleType.setText("");
        txtBrand.setText("");
        txtModel.setText("");
        comboAvailability.setSelectedIndex(0);
        table.clearSelection();
    }

    public List<Vehicle> getVehicleList() {
        List<Vehicle> list = new ArrayList<>();
        for (int i = 0; i < model.getRowCount(); i++) {
            list.add(new Vehicle(
                model.getValueAt(i, 0).toString(),
                model.getValueAt(i, 1).toString(),
                model.getValueAt(i, 2).toString(),
                model.getValueAt(i, 3).toString(),
                model.getValueAt(i, 4).toString()
            ));
        }
        return list;
    }

    public void loadVehicleList(List<Vehicle> vehicles) {
        model.setRowCount(0);
        for (Vehicle v : vehicles) {
            model.addRow(v.toRow());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AddVehicleFrame().setVisible(true));
    }
}

// Helper Vehicle class
class Vehicle {
    String id, type, brand, model, availability;

    public Vehicle(String id, String type, String brand, String model, String availability) {
        this.id = id;
        this.type = type;
        this.brand = brand;
        this.model = model;
        this.availability = availability;
    }

    public Object[] toRow() {
        return new Object[]{id, type, brand, model, availability};
    }
}*/
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import com.mycompany.vehiclerentalsystem.Vehicle;

public class AddVehicleFrame extends JFrame {
    private JTextField txtVehicleID, txtVehicleType, txtBrand, txtModel;
    private JComboBox<String> comboAvailability;
    private JTable table;
    private DefaultTableModel model;

    public AddVehicleFrame() {
        setTitle("Add Vehicle");
        setSize(800, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        model = new DefaultTableModel(new String[]{"ID", "Type", "Brand", "Model", "Availability"}, 0);
        table = new JTable(model);

        add(createInputPanel(), BorderLayout.NORTH);
        add(createButtonPanel(), BorderLayout.CENTER);
        add(createTablePanel(), BorderLayout.SOUTH);
    }

    private JPanel createInputPanel() {
        JPanel inputPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        inputPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("Vehicle Details"),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));

        txtVehicleID = new JTextField();
        txtVehicleType = new JTextField();
        txtBrand = new JTextField();
        txtModel = new JTextField();
        comboAvailability = new JComboBox<>(new String[]{"Available", "Not Available"});

        inputPanel.add(new JLabel("Vehicle ID:")); inputPanel.add(txtVehicleID);
        inputPanel.add(new JLabel("Type:")); inputPanel.add(txtVehicleType);
        inputPanel.add(new JLabel("Brand:")); inputPanel.add(txtBrand);
        inputPanel.add(new JLabel("Model:")); inputPanel.add(txtModel);
        inputPanel.add(new JLabel("Availability:")); inputPanel.add(comboAvailability);

        return inputPanel;
    }

    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel(new FlowLayout());

        JButton btnAdd = new JButton("Add");
        JButton btnUpdate = new JButton("Update");
        JButton btnDelete = new JButton("Delete");

        buttonPanel.add(btnAdd);
        buttonPanel.add(btnUpdate);
        buttonPanel.add(btnDelete);

        btnAdd.addActionListener(e -> addVehicle());
        btnUpdate.addActionListener(e -> updateVehicle());
        btnDelete.addActionListener(e -> deleteVehicle());

        return buttonPanel;
    }

    private JScrollPane createTablePanel() {
        JScrollPane scrollPane = new JScrollPane(table);

        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                txtVehicleID.setText(model.getValueAt(row, 0).toString());
                txtVehicleType.setText(model.getValueAt(row, 1).toString());
                txtBrand.setText(model.getValueAt(row, 2).toString());
                txtModel.setText(model.getValueAt(row, 3).toString());
                comboAvailability.setSelectedItem(model.getValueAt(row, 4).toString());
            }
        });

        return scrollPane;
    }

    private void addVehicle() {
        Vehicle v = getVehicleFromForm();
        if (v == null) return;

        if (isDuplicateID(v.getId(), -1)) {
            JOptionPane.showMessageDialog(this, "Vehicle ID already exists.");
            return;
        }

        model.addRow(v.toRow());
        clearForm();
    }

    private void updateVehicle() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Select a row to update.");
            return;
        }

        Vehicle v = getVehicleFromForm();
        if (v == null) return;

        if (isDuplicateID(v.getId(), row)) {
            JOptionPane.showMessageDialog(this, "Vehicle ID already exists.");
            return;
        }

        for (int i = 0; i < 5; i++) {
            model.setValueAt(v.toRow()[i], row, i);
        }

        clearForm();
    }

    private void deleteVehicle() {
        int row = table.getSelectedRow();
        if (row != -1) {
            model.removeRow(row);
            clearForm();
        } else {
            JOptionPane.showMessageDialog(this, "Select a row to delete.");
        }
    }

    private Vehicle getVehicleFromForm() {
        String id = txtVehicleID.getText().trim();
        String type = txtVehicleType.getText().trim();
        String brand = txtBrand.getText().trim();
        String modelText = txtModel.getText().trim();
        String availability = (String) comboAvailability.getSelectedItem();

        if (id.isEmpty() || type.isEmpty() || brand.isEmpty() || modelText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.");
            return null;
        }

        return new Vehicle(id, type, brand, modelText, availability);
    }

    private boolean isDuplicateID(String id, int excludeRow) {
        for (int i = 0; i < model.getRowCount(); i++) {
            if (i != excludeRow && model.getValueAt(i, 0).toString().equals(id)) {
                return true;
            }
        }
        return false;
    }

    private void clearForm() {
        txtVehicleID.setText("");
        txtVehicleType.setText("");
        txtBrand.setText("");
        txtModel.setText("");
        comboAvailability.setSelectedIndex(0);
        table.clearSelection();
    }

    public List<Vehicle> getVehicleList() {
        List<Vehicle> list = new ArrayList<>();
        for (int i = 0; i < model.getRowCount(); i++) {
            list.add(new Vehicle(
                model.getValueAt(i, 0).toString(),
                model.getValueAt(i, 1).toString(),
                model.getValueAt(i, 2).toString(),
                model.getValueAt(i, 3).toString(),
                model.getValueAt(i, 4).toString()
            ));
        }
        return list;
    }

    public void loadVehicleList(List<Vehicle> vehicles) {
        model.setRowCount(0);
        for (Vehicle v : vehicles) {
            model.addRow(v.toRow());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AddVehicleFrame().setVisible(true));
    }
}


