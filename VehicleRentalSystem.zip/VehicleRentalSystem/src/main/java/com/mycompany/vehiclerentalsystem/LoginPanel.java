/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.vehiclerentalsystem;

/**
 *
 * @author Az
 */
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class LoginPanel extends JPanel {

    public LoginPanel(CardLayout cardLayout, JPanel mainPanel, ArrayList<Vehicle> vehicles) {
        setLayout(null);
        setBackground(Color.WHITE);

        JLabel userLabel = new JLabel("Username:");
        userLabel.setBounds(200, 150, 100, 25);
        add(userLabel);

        JTextField username = new JTextField();
        username.setBounds(300, 150, 180, 25);
        add(username);

        JLabel passLabel = new JLabel("Password:");
        passLabel.setBounds(200, 190, 100, 25);
        add(passLabel);

        JPasswordField password = new JPasswordField();
        password.setBounds(300, 190, 180, 25);
        add(password);

        JButton loginBtn = createStyledButton("Login");
        loginBtn.setBounds(270, 240, 150, 35);
        add(loginBtn);

        // Disabling login button initially until both fields are filled
        loginBtn.setEnabled(false);

        // Enable/Disable login button based on input
        username.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { toggleLoginButton(); }
            @Override
            public void removeUpdate(DocumentEvent e) { toggleLoginButton(); }
            @Override
            public void changedUpdate(DocumentEvent e) { toggleLoginButton(); }

            private void toggleLoginButton() {
                loginBtn.setEnabled(!username.getText().trim().isEmpty() && password.getPassword().length > 0);
            }
        });

        password.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { toggleLoginButton(); }
            @Override
            public void removeUpdate(DocumentEvent e) { toggleLoginButton(); }
            @Override
            public void changedUpdate(DocumentEvent e) { toggleLoginButton(); }

            private void toggleLoginButton() {
                loginBtn.setEnabled(!username.getText().trim().isEmpty() && password.getPassword().length > 0);
            }
        });

        loginBtn.addActionListener(e -> {
            String user = username.getText().trim();
            String pass = new String(password.getPassword());

            if (user.isEmpty() || pass.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill both fields.", "Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (user.equals("admin") && pass.equals("1234")) {
                cardLayout.show(mainPanel, "MainMenu");
            } else {
                JOptionPane.showMessageDialog(this, "Invalid credentials!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Verdana", Font.PLAIN, 16));
        button.setBackground(new Color(0, 102, 204));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        return button;
    }
}
