/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.vehiclerentalsystem;

/**
 *
 * @author Az
 */
 
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class RentVehicleFrame extends JFrame {
    private JTable table;
    private DefaultTableModel model;
    private JButton btnRent;

    public RentVehicleFrame() {
        setTitle("Rent Vehicle");
        setSize(700, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        model = new DefaultTableModel(new String[]{"Vehicle ID", "Type", "Brand", "Model", "Availability"}, 0);
        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);

        btnRent = new JButton("Rent Selected Vehicle");
        add(btnRent, BorderLayout.SOUTH);

        btnRent.addActionListener(e -> rentSelectedVehicle());
    }

    private void rentSelectedVehicle() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select a vehicle to rent.");
            return;
        }

        String availability = model.getValueAt(row, 4).toString();
        if (availability.equalsIgnoreCase("Not Available")) {
            JOptionPane.showMessageDialog(this, "Vehicle is already rented.");
            return;
        }

        model.setValueAt("Not Available", row, 4);
        JOptionPane.showMessageDialog(this, "Vehicle rented successfully.");
    }

    public void loadVehicles(List<Vehicle> vehicles) {
        model.setRowCount(0); // clear old data
        for (Vehicle v : vehicles) {
            model.addRow(v.toRow());
        }
    }

    public List<Vehicle> getUpdatedVehicles() {
        List<Vehicle> updatedList = new ArrayList<>();
        for (int i = 0; i < model.getRowCount(); i++) {
            updatedList.add(new Vehicle(
                model.getValueAt(i, 0).toString(),
                model.getValueAt(i, 1).toString(),
                model.getValueAt(i, 2).toString(),
                model.getValueAt(i, 3).toString(),
                model.getValueAt(i, 4).toString()
            ));
        }
        return updatedList;
    }
}

