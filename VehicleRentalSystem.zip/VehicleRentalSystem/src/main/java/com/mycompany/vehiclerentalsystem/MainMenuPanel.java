/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.vehiclerentalsystem;

/**
 *
 * @author Az
 */
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class MainMenuPanel extends JPanel {

    public MainMenuPanel(CardLayout cardLayout, JPanel mainPanel) {
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        // Title Label
        JLabel label = new JLabel("Main Menu", SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 26));
        label.setForeground(new Color(0, 120, 215));
        add(label, BorderLayout.NORTH);

        // Button Panel with action buttons
        JPanel buttonPanel = new JPanel(new GridLayout(2, 2, 20, 20));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(30, 100, 30, 100));
        buttonPanel.setBackground(Color.WHITE);

        String[] actions = {"Add Vehicle", "Rent Vehicle", "Return Vehicle", "View All Vehicles"};
        for (String action : actions) {
            JButton btn = createStyledButton(action);
            buttonPanel.add(btn);
            btn.addActionListener(e -> handleAction(action, cardLayout, mainPanel));
        }

        add(buttonPanel, BorderLayout.CENTER);
    }

    MainMenuPanel(CardLayout cardLayout, JPanel mainPanel, ArrayList<Vehicle> vehicles) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void handleAction(String action, CardLayout cardLayout, JPanel mainPanel) {
        switch (action) {
            case "Add Vehicle":
                cardLayout.show(mainPanel, "AddVehicle");
                break;
            case "Rent Vehicle":
                cardLayout.show(mainPanel, "RentVehicle");
                break;
            case "Return Vehicle":
                cardLayout.show(mainPanel, "ReturnVehicle");
                break;
            case "View All Vehicles":
                cardLayout.show(mainPanel, "ViewVehicles");
                break;
            default:
                break;
        }
    }

    private JButton createStyledButton(String action) {
        JButton button = new JButton(action);
        button.setFont(new Font("Arial", Font.PLAIN, 16));
        button.setBackground(new Color(0, 120, 215));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        return button;
    }
}
