/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.dishes;
import java.util.Scanner;
/**
 *
 * @author Az
 */
public class Dishes {
    String type;
    String ingredients;
    String cuisine;

    public static void main(String[] args) {
        Scanner food= new Scanner(System.in);
        Dishes choice=new Dishes();
        System.out.println("Enter the type of dish(sweets , savory. etc) : ");
        choice.type=food.nextLine();
        System.out.println("Enter the ingredients : ");
        choice.ingredients=food.nextLine();
        System.out.println("Enter the cuisine : ");
        choice.cuisine=food.nextLine();
        
        System.out.println("====WELCOME TO THE ASIAN RESTAURANT=== ");
        System.out.println("Your selected choice of Dish is(type of dish) " + choice.type);
        System.out.println("Your dish contains the following ingredients(ingredients) " + choice.ingredients);
        System.out.println("Your dish belong to the(cuisine) " + choice.cuisine);
        food.close();    
    }
}
