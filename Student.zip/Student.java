/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Az
 */
import java.util.Scanner;
public class Student {
    private String name;
    private int rollNumber;
    private String department;
    //default constructor
    public Student(){
        this.name="Unknown";
        this.rollNumber=0;
        this.department="Unknown";
    }
    //parametrized constructor
    public Student(String name,int rollNumber, String department){
        this.name=name;
        this.rollNumber=rollNumber;
        this.department=department;
}
    //copy constructor
    public Student(Student s){
        this.name=s.name;
        this.rollNumber=s.rollNumber;
        this.department=s.department;
  
    }
    public void displayStudent(){
        System.out.println("Student Name:" +name);
        System.out.println("Student roll number:" +rollNumber);
        System.out.println("Department Name:" +department);
    }
    public static void main(String[] args){
        Scanner input=new Scanner(System.in);
        Scanner inputInt=new Scanner(System.in);
        System.out.println("Enter Department Name:" );
        String department=input.nextLine();
        System.out.println("Enter Student Name:" );
        String name1=input.nextLine();
        System.out.println("Enter Student roll number:" );
        int rollNumber1=inputInt.nextInt();
        Student student1=new Student(name1, rollNumber1, department);
        
        System.out.println("Enter Student Name:" );
        String name2=input.nextLine();
        System.out.println("Enter Student roll number:" );
        int rollNumber2=inputInt.nextInt();
        Student student2=new Student(name2, rollNumber2, department);
        student1.displayStudent();
        student2.displayStudent();
                
        input.close();
        
    }
            
    
    
}
