/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Az
 */
import java.util.Scanner;
public class Department {
    private String deptName;
    private String deptHead;
    //default constructor
    public Department(){
        this.deptName="Unknown";
        this.deptHead="Unknown";
    }
    //parametrized constructor
    public Department(String deptName,String deptHead){
        this.deptName=deptName;
        this.deptHead=deptHead;
    }
    //copy constructor
    public Department(Department d){
        this.deptName=d.deptName;
        this.deptHead=d.deptHead;
    }
    //display function
    public void displayDepartment(){
        System.out.println("Department Name:" +deptName);
        System.out.println("Department Head:" +deptHead);
        
    }
    public static void main(String[] args){
        Scanner input=new Scanner(System.in);
        System.out.println("Enter Department Name:");
        String deptName=input.nextLine();
        System.out.println("Enter Department Head:" );
        String deptHead=input.nextLine();
        Department department=new Department(deptName, deptHead);
        department.displayDepartment();
        input.close();
        
    }
    
}
