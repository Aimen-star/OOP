/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.candycrush;

/**
 *
 * @author Az
 */
import java.util.Scanner;
public class CandyCrush {
    String PlayerName="ALI";
    int PlayerScore=20;
    int PlayerLevel= 1;
   public String getPlayerName(){
       return PlayerName;
}
    public int getPlayerScore(){
    return PlayerScore;
    }
    public int getPlayerLevel(){
    return PlayerLevel;
    }
    public void setPlayerName(String PlayerName){
        this.PlayerName=PlayerName;
    }
    public void setPlayerScore(int PlayerScore){
        this.PlayerScore=PlayerScore;
    }
     public void setPlayerLevel(int PlayerLevel){
        this.PlayerLevel=PlayerLevel;
    }
     public void matchCandies() {
        this.PlayerScore += 20;
        System.out.println(PlayerName + " matched candies and earned 20 points!");
    }
     public void clearRow(){
         this.PlayerScore +=30;
          System.out.println(PlayerName + " cleared a row  and earned 30 points!");
     }
     public void completeLevel(){
         this.PlayerLevel +=1;
          System.out.println(PlayerName + " completed level " );
          System.out.println(PlayerName + " Advanced level " + PlayerLevel );
     }
        public void displayProgress() {
        System.out.println("Player: " + PlayerName);
        System.out.println("Score: " + PlayerScore);
        System.out.println("Level: " + PlayerLevel);
    } 
        public void playerAction(int Action){
            switch(Action){
                case 1:
                    matchCandies();
                    break;
                case 2:
                    clearRow();
                    break;
                case 3:
                    completeLevel();
                    break;
                case 4:
                    System.out.println("Invalid Action");
              
        }
        }
    public static void main(String[] args) {
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter Player Name");
        String PlayerName=scan.nextLine();
        CandyCrush game=new CandyCrush();
        
        
        
    }
       
    
}
