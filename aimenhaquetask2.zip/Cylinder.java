/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aimenhaquetask2;

/**
 *
 * @author Az
 */
import java.util.Scanner;
public class Cylinder extends Shape3D {
    double radius;
    double height;
    void getInput(){
        Scanner scan=new Scanner(System.in);
        System.out.println(" Radius: " );
          radius =scan.nextDouble();   
          System.out.println(" Height: ");
          height =scan.nextDouble();   
          scan.close();
    }
    double calculateBaseArea(){
        return 3.14*radius*radius;
    }
    void displayBaseArea(){
        System.out.println("Base Area of Cylinder "+ calculateBaseArea() );
    }
   
}
