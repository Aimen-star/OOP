/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.aimenhaquetask2;

/**
 *
 * @author Az
 */
public class AimenHaqueTask2 {

    public static void main(String[] args) {
       SolidCylinder s=new SolidCylinder();
       s.display();
       s.getInput();
       s.displayBaseArea();
       s.displayVolume();
    }
}
