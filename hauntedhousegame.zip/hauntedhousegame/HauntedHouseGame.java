/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.hauntedhousegame;

/**
 *
 * @author Az
 */
import java.util.Scanner;
public class HauntedHouseGame {

    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        String[] mysteryWords={"Ghost", "Vampire" ,"Zombie"};
        int score=0;
        System.out.println(" Welcome to the Haunted House Escape! ");
         System.out.println(" Solve the mystery words to escape... ");
         for(int i=0; i<mysteryWords.length; i++){
             String mysteryWord=mysteryWords[i];
             //to get first character of mystery word
             char hint =mysteryWord.charAt(0);
             String guess;
              System.out.println(" Room " + (i + 1) + " : Guess the Mystery Word!");
               System.out.println(" Hint: The word starts with '"+ hint + "'" );
         
               do{
                    System.out.print("Your Guess: ");
                    // Convert guess to uppercase
                guess = input.nextLine().toUpperCase();  

                // Checkong if the guess is correct
                if (guess.equals(mysteryWord.toUpperCase())) {
                    System.out.println("Correct Guess! Moving to the next room...\n");
                    score++; 
                    break;  
                } else {
                    System.out.println("Incorrect Guess! Try Again.");
                }

            } while (true);  // Keep looping until the correct guess is made
        }
          //displaying result
                          System.out.println(" Game Over! Your Score" + score + "/"+ mysteryWords.length);
                           System.out.println(" Congratulations! you escaped the Haunted House ");
               
             input.close();
             
         }
}

